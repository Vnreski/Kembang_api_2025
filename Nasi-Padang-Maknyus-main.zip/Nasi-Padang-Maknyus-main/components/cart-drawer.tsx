"use client"

import { useState } from "react"
import Image from "next/image"
import { ShoppingCart, Minus, Plus, Trash2, X, Send } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useCart } from "@/lib/cart-context"
import { formatPrice } from "@/lib/menu-data"

export function CartDrawer() {
  const { items, updateQuantity, removeItem, clearCart, totalItems, subtotal, discount, totalPrice, hasDiscount } = useCart()
  const [isOpen, setIsOpen] = useState(false)
  const [isCheckout, setIsCheckout] = useState(false)
  const [customerName, setCustomerName] = useState("")
  const [customerPhone, setCustomerPhone] = useState("")
  const [customerAddress, setCustomerAddress] = useState("")
  const [notes, setNotes] = useState("")
  const [orderSuccess, setOrderSuccess] = useState(false)

  const handleCheckout = () => {
    setIsCheckout(true)
  }

  const handleSubmitOrder = () => {
    // Simulate order submission
    setOrderSuccess(true)
    setTimeout(() => {
      clearCart()
      setIsCheckout(false)
      setOrderSuccess(false)
      setCustomerName("")
      setCustomerPhone("")
      setCustomerAddress("")
      setNotes("")
      setIsOpen(false)
    }, 3000)
  }

  const handleBackToCart = () => {
    setIsCheckout(false)
  }

  const isFormValid = customerName.trim() && customerPhone.trim() && customerAddress.trim()

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <Button variant="default" size="icon" className="relative">
          <ShoppingCart className="h-5 w-5" />
          {totalItems > 0 && (
            <Badge className="absolute -right-2 -top-2 h-5 w-5 justify-center rounded-full bg-destructive p-0 text-xs text-primary-foreground">
              {totalItems}
            </Badge>
          )}
          <span className="sr-only">Keranjang belanja</span>
        </Button>
      </SheetTrigger>
      <SheetContent className="flex w-full flex-col sm:max-w-lg">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <ShoppingCart className="h-5 w-5" />
            {isCheckout ? "Checkout Pesanan" : "Keranjang Belanja"}
          </SheetTitle>
        </SheetHeader>

        {orderSuccess ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-4 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-green-100">
              <svg
                className="h-8 w-8 text-green-600"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M5 13l4 4L19 7"
                />
              </svg>
            </div>
            <h3 className="text-lg font-semibold text-foreground">Pesanan Berhasil!</h3>
            <p className="text-sm text-muted-foreground">
              Terima kasih, {customerName}. Pesanan Anda sedang diproses dan akan segera dikirim.
            </p>
          </div>
        ) : isCheckout ? (
          <div className="flex flex-1 flex-col gap-4 overflow-y-auto py-4">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nama Lengkap *</Label>
                <Input
                  id="name"
                  placeholder="Masukkan nama lengkap"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Nomor WhatsApp *</Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="08xx-xxxx-xxxx"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="address">Alamat Pengiriman *</Label>
                <Textarea
                  id="address"
                  placeholder="Masukkan alamat lengkap"
                  value={customerAddress}
                  onChange={(e) => setCustomerAddress(e.target.value)}
                  rows={3}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="notes">Catatan (opsional)</Label>
                <Textarea
                  id="notes"
                  placeholder="Catatan tambahan untuk pesanan"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={2}
                />
              </div>
            </div>

            <Separator />

            <div className="space-y-2">
              <h4 className="font-medium text-foreground">Ringkasan Pesanan</h4>
              {items.map((item) => (
                <div key={item.id} className="flex justify-between text-sm">
                  <span className="text-muted-foreground">
                    {item.name} x{item.quantity}
                  </span>
                  <span className="text-foreground">{formatPrice(item.price * item.quantity)}</span>
                </div>
              ))}
              <Separator />
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Subtotal</span>
                <span className="text-foreground">{formatPrice(subtotal)}</span>
              </div>
              {hasDiscount && (
                <div className="flex justify-between text-sm">
                  <span className="text-green-600">Diskon 10%</span>
                  <span className="text-green-600">-{formatPrice(discount)}</span>
                </div>
              )}
              <Separator />
              <div className="flex justify-between font-semibold">
                <span>Total Bayar</span>
                <span className="text-primary">{formatPrice(totalPrice)}</span>
              </div>
            </div>

            <div className="mt-auto space-y-2">
              <Button
                className="w-full"
                onClick={handleSubmitOrder}
                disabled={!isFormValid}
              >
                <Send className="mr-2 h-4 w-4" />
                Kirim Pesanan
              </Button>
              <Button variant="outline" className="w-full" onClick={handleBackToCart}>
                Kembali ke Keranjang
              </Button>
            </div>
          </div>
        ) : items.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-4 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-secondary">
              <ShoppingCart className="h-8 w-8 text-muted-foreground" />
            </div>
            <p className="text-muted-foreground">Keranjang belanja kosong</p>
            <Button variant="outline" onClick={() => setIsOpen(false)}>
              Lihat Menu
            </Button>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto py-4">
              <div className="space-y-4">
                {items.map((item) => (
                  <div key={item.id} className="flex gap-3">
                    <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-lg">
                      <Image
                        src={item.image}
                        alt={item.name}
                        fill
                        className="object-cover"
                        sizes="80px"
                      />
                    </div>
                    <div className="flex flex-1 flex-col justify-between">
                      <div>
                        <h4 className="font-medium text-foreground">{item.name}</h4>
                        <p className="text-sm text-primary">{formatPrice(item.price)}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        >
                          <Minus className="h-4 w-4" />
                        </Button>
                        <span className="w-8 text-center font-medium">{item.quantity}</span>
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        >
                          <Plus className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="ml-auto h-8 w-8 text-destructive hover:bg-destructive/10 hover:text-destructive"
                          onClick={() => removeItem(item.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="border-t border-border pt-4">
              <div className="mb-4 space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span className="text-foreground">{formatPrice(subtotal)}</span>
                </div>
                {hasDiscount ? (
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-green-600">Diskon 10%</span>
                    <span className="text-green-600">-{formatPrice(discount)}</span>
                  </div>
                ) : (
                  <div className="text-xs text-muted-foreground">
                    Belanja min. Rp 100.000 untuk diskon 10%
                  </div>
                )}
                <Separator />
                <div className="flex items-center justify-between">
                  <span className="text-lg font-semibold text-foreground">Total Bayar</span>
                  <span className="text-lg font-bold text-primary">{formatPrice(totalPrice)}</span>
                </div>
              </div>
              <div className="space-y-2">
                <Button className="w-full" onClick={handleCheckout}>
                  Checkout ({totalItems} item)
                </Button>
                <Button variant="outline" className="w-full" onClick={clearCart}>
                  Kosongkan Keranjang
                </Button>
              </div>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  )
}
