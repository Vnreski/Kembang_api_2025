"use client"

import Image from "next/image"
import { Flame, Star, Plus, Check } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import type { MenuItem } from "@/lib/menu-data"
import { formatPrice } from "@/lib/menu-data"
import { useCart } from "@/lib/cart-context"
import { useState, useEffect } from "react"

interface MenuCardProps {
  item: MenuItem
}

export function MenuCard({ item }: MenuCardProps) {
  const { addItem, items } = useCart()
  const [justAdded, setJustAdded] = useState(false)
  
  const itemInCart = items.find((i) => i.id === item.id)
  const quantityInCart = itemInCart?.quantity || 0

  const handleAddToCart = () => {
    addItem(item)
    setJustAdded(true)
  }

  useEffect(() => {
    if (justAdded) {
      const timer = setTimeout(() => setJustAdded(false), 1000)
      return () => clearTimeout(timer)
    }
  }, [justAdded])

  return (
    <Card className="group overflow-hidden border-border bg-card transition-all hover:shadow-lg">
      <div className="relative aspect-[4/3] overflow-hidden">
        <Image
          src={item.image}
          alt={item.name}
          fill
          className="object-cover transition-transform duration-300 group-hover:scale-105"
          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
        />
        <div className="absolute right-2 top-2 flex gap-1">
          {item.isPopular && (
            <Badge className="bg-accent text-accent-foreground">
              <Star className="mr-1 h-3 w-3" />
              Favorit
            </Badge>
          )}
          {item.isSpicy && (
            <Badge variant="destructive" className="bg-destructive text-primary-foreground">
              <Flame className="mr-1 h-3 w-3" />
              Pedas
            </Badge>
          )}
        </div>
        {quantityInCart > 0 && (
          <div className="absolute left-2 top-2">
            <Badge className="bg-primary text-primary-foreground">
              {quantityInCart} di keranjang
            </Badge>
          </div>
        )}
      </div>
      <CardContent className="p-4">
        <div className="mb-2 flex items-start justify-between gap-2">
          <h3 className="font-semibold text-card-foreground">{item.name}</h3>
          <span className="shrink-0 font-bold text-primary">{formatPrice(item.price)}</span>
        </div>
        <p className="mb-4 text-sm leading-relaxed text-muted-foreground">{item.description}</p>
        <Button
          className="w-full"
          onClick={handleAddToCart}
          variant={justAdded ? "secondary" : "default"}
        >
          {justAdded ? (
            <>
              <Check className="mr-2 h-4 w-4" />
              Ditambahkan!
            </>
          ) : (
            <>
              <Plus className="mr-2 h-4 w-4" />
              Tambah ke Keranjang
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  )
}
