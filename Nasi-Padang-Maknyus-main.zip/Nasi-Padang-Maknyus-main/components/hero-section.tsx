import Image from "next/image"

export function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-primary py-16 sm:py-24">
      <div className="absolute inset-0 bg-[url('/images/rendang.jpg')] bg-cover bg-center opacity-20" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-balance text-4xl font-bold tracking-tight text-primary-foreground sm:text-5xl lg:text-6xl">
            Nasi Padang Maknyus
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-pretty text-lg text-primary-foreground/80 sm:text-xl">
            Pesan masakan Padang autentik secara online dengan cita rasa khas Minangkabau. Pilih menu favoritmu dan kami antar ke tempatmu!
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
            <div className="flex items-center gap-2 rounded-full bg-primary-foreground/10 px-4 py-2 backdrop-blur">
              <span className="text-sm font-medium text-primary-foreground">Pesan Online 24 Jam</span>
            </div>
            <div className="flex items-center gap-2 rounded-full bg-primary-foreground/10 px-4 py-2 backdrop-blur">
              <span className="text-sm font-medium text-primary-foreground">Gratis Ongkir 3km</span>
            </div>
            <div className="flex items-center gap-2 rounded-full bg-primary-foreground/10 px-4 py-2 backdrop-blur">
              <span className="text-sm font-medium text-primary-foreground">Pengiriman 10:00 - 22:00</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
