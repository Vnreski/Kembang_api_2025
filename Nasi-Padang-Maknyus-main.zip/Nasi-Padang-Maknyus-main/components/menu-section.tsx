import { MenuCard } from "@/components/menu-card"
import type { MenuCategory } from "@/lib/menu-data"

interface MenuSectionProps {
  category: MenuCategory
}

export function MenuSection({ category }: MenuSectionProps) {
  return (
    <section id={category.id} className="scroll-mt-20">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-foreground">{category.name}</h2>
        <p className="mt-1 text-muted-foreground">{category.description}</p>
      </div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {category.items.map((item) => (
          <MenuCard key={item.id} item={item} />
        ))}
      </div>
    </section>
  )
}
