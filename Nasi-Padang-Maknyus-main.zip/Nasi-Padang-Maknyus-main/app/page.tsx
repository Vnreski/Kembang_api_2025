"use client"

import { useState, useEffect } from "react"
import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { MenuSection } from "@/components/menu-section"
import { menuCategories } from "@/lib/menu-data"

export default function MenuPage() {
  const [activeCategory, setActiveCategory] = useState(menuCategories[0].id)

  const handleCategoryClick = (categoryId: string) => {
    setActiveCategory(categoryId)
    const element = document.getElementById(categoryId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  useEffect(() => {
    const handleScroll = () => {
      const sections = menuCategories.map((cat) => ({
        id: cat.id,
        element: document.getElementById(cat.id),
      }))

      for (const section of sections) {
        if (section.element) {
          const rect = section.element.getBoundingClientRect()
          if (rect.top <= 100 && rect.bottom >= 100) {
            setActiveCategory(section.id)
            break
          }
        }
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const categoryNav = menuCategories.map((cat) => ({ id: cat.id, name: cat.name }))

  return (
    <div className="min-h-screen">
      <Header
        categories={categoryNav}
        activeCategory={activeCategory}
        onCategoryClick={handleCategoryClick}
      />
      
      <HeroSection />

      <main className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="space-y-16">
          {menuCategories.map((category) => (
            <MenuSection key={category.id} category={category} />
          ))}
        </div>
      </main>

      <footer className="border-t border-border bg-card py-8">
        <div className="mx-auto max-w-7xl px-4 text-center sm:px-6 lg:px-8">
          <div className="flex items-center justify-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary">
              <span className="text-sm font-bold text-primary-foreground">NP</span>
            </div>
            <span className="font-semibold text-foreground">Nasi Padang Maknyus</span>
          </div>
          <p className="mt-4 text-sm text-muted-foreground">
            Jl. Kuliner Nusantara No. 123, Jakarta Selatan
          </p>
          <p className="mt-1 text-sm text-muted-foreground">
            Telepon: (021) 123-4567 | WhatsApp: 0812-3456-7890
          </p>
          <p className="mt-4 text-xs text-muted-foreground">
            &copy; {new Date().getFullYear()} Nasi Padang Maknyus. Semua hak dilindungi.
          </p>
        </div>
      </footer>
    </div>
  )
}
