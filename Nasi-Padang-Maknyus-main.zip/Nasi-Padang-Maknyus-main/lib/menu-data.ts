export interface MenuItem {
  id: string
  name: string
  description: string
  price: number
  image: string
  isSpicy?: boolean
  isPopular?: boolean
}

export interface MenuCategory {
  id: string
  name: string
  description: string
  items: MenuItem[]
}

export const menuCategories: MenuCategory[] = [
  {
    id: "lauk-daging",
    name: "Lauk Daging",
    description: "Aneka olahan daging sapi pilihan",
    items: [
      {
        id: "rendang",
        name: "Rendang Daging",
        description: "Daging sapi empuk dimasak dengan bumbu rempah khas Minang hingga kering",
        price: 35000,
        image: "/images/rendang.jpg",
        isPopular: true,
      },
      {
        id: "dendeng-balado",
        name: "Dendeng Balado",
        description: "Irisan daging tipis goreng kering dengan sambal balado merah pedas",
        price: 30000,
        image: "/images/dendeng-balado.jpg",
        isSpicy: true,
      },
      {
        id: "gulai-otak",
        name: "Gulai Otak",
        description: "Otak sapi dimasak dengan kuah santan kuning yang gurih",
        price: 28000,
        image: "/images/gulai-otak.jpg",
      },
    ],
  },
  {
    id: "lauk-ayam",
    name: "Lauk Ayam",
    description: "Hidangan ayam kampung pilihan",
    items: [
      {
        id: "ayam-pop",
        name: "Ayam Pop",
        description: "Ayam kukus khas Padang dengan kulit lembut dan daging juicy",
        price: 28000,
        image: "/images/ayam-pop.jpg",
        isPopular: true,
      },
      {
        id: "ayam-bakar",
        name: "Ayam Bakar Padang",
        description: "Ayam bakar dengan bumbu rempah dan olesan sambal merah",
        price: 30000,
        image: "/images/ayam-pop.jpg",
        isSpicy: true,
      },
      {
        id: "gulai-ayam",
        name: "Gulai Ayam",
        description: "Ayam kampung dimasak dengan kuah santan kuning gurih",
        price: 28000,
        image: "/images/ayam-pop.jpg",
      },
    ],
  },
  {
    id: "lauk-ikan",
    name: "Lauk Ikan & Seafood",
    description: "Aneka ikan dan hasil laut segar",
    items: [
      {
        id: "ikan-bakar",
        name: "Ikan Bakar Padang",
        description: "Ikan segar dibakar dengan bumbu padang dan sambal merah",
        price: 40000,
        image: "/images/ikan-bakar.jpg",
        isSpicy: true,
        isPopular: true,
      },
      {
        id: "gulai-ikan",
        name: "Gulai Ikan",
        description: "Ikan segar dimasak dengan kuah santan kuning kental",
        price: 35000,
        image: "/images/ikan-bakar.jpg",
      },
      {
        id: "ikan-balado",
        name: "Ikan Balado",
        description: "Ikan goreng dengan siraman sambal balado pedas",
        price: 38000,
        image: "/images/ikan-bakar.jpg",
        isSpicy: true,
      },
    ],
  },
  {
    id: "sayuran",
    name: "Sayuran",
    description: "Aneka sayur dan pelengkap",
    items: [
      {
        id: "sayur-nangka",
        name: "Gulai Nangka",
        description: "Nangka muda dimasak dengan santan dan bumbu gulai",
        price: 15000,
        image: "/images/sayur-nangka.jpg",
      },
      {
        id: "daun-singkong",
        name: "Daun Singkong",
        description: "Daun singkong rebus dengan sambal kelapa parut",
        price: 12000,
        image: "/images/sayur-nangka.jpg",
      },
      {
        id: "sayur-pakis",
        name: "Gulai Pakis",
        description: "Pucuk pakis segar dimasak dengan santan gurih",
        price: 15000,
        image: "/images/sayur-nangka.jpg",
      },
    ],
  },
  {
    id: "telur",
    name: "Telur",
    description: "Aneka olahan telur",
    items: [
      {
        id: "telur-balado",
        name: "Telur Balado",
        description: "Telur rebus dengan sambal balado merah pedas",
        price: 12000,
        image: "/images/telur-balado.jpg",
        isSpicy: true,
        isPopular: true,
      },
      {
        id: "telur-dadar",
        name: "Telur Dadar Padang",
        description: "Telur dadar tebal khas Padang dengan daun bawang",
        price: 10000,
        image: "/images/telur-balado.jpg",
      },
      {
        id: "telur-gulai",
        name: "Telur Gulai",
        description: "Telur rebus dengan kuah santan kuning gurih",
        price: 12000,
        image: "/images/telur-balado.jpg",
      },
    ],
  },
  {
    id: "sambal",
    name: "Sambal & Pelengkap",
    description: "Aneka sambal dan pelengkap",
    items: [
      {
        id: "sambal-ijo",
        name: "Sambal Ijo",
        description: "Sambal cabai hijau khas Padang yang segar dan pedas",
        price: 8000,
        image: "/images/sambal-ijo.jpg",
        isSpicy: true,
        isPopular: true,
      },
      {
        id: "sambal-merah",
        name: "Sambal Merah",
        description: "Sambal cabai merah dengan bawang goreng",
        price: 8000,
        image: "/images/sambal-ijo.jpg",
        isSpicy: true,
      },
      {
        id: "kerupuk-kulit",
        name: "Kerupuk Kulit",
        description: "Kerupuk kulit sapi renyah",
        price: 5000,
        image: "/images/sambal-ijo.jpg",
      },
    ],
  },
]

export const formatPrice = (price: number): string => {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    minimumFractionDigits: 0,
  }).format(price)
}
